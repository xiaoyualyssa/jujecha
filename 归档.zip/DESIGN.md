# DESIGN.md · 看见自己 · 每日觉察手账（路演 · 6 页版）

## 设计总则

通用设计原则。温暖治愈系，卡片化呈现，克制留白。

## 1. 画布与母版

- 画布 1280×720；内容页三区：A 标题块 0–120px / B 内容区 120–660px / C 页脚条 660–720px。
- 左右 padding 80px（第 3 页核心功能用 60px 以容纳三列卡片）。
- 封面(01)、收尾(06)自定义版式，省略 C 区。

## 2. 颜色系统

| 角色 | 色值 |
|---|---|
| 主色 sage | #5A7D7C |
| 辅色 blush | #F5E6E8 |
| 辅色 mist | #E8EEF2 |
| 强调 暖砖红 | #C98A8A |
| 背景 cream | #FAF8F5 |
| 文本主 ink | #3F3B36 |
| 文本次 warmgray | #8B8680 |

强调色 ≤10%（hero 页 ≤20%）；主色 ≤60%；辅色 ≤30%。

## 3. 字体

标题思源黑体/苹方 bold；正文同字体 regular；巨型数字 Inter bold。

| 层级 | 字号 | 字重 |
|---|---|---|
| 封面主标题 | 80px | bold |
| 页面主标题 | 34px | bold |
| 卡片小标题 | 24px | 600 |
| 正文 | 18–22px | regular |
| 巨型数据 | 72–96px | bold |
| 页脚 | 14px | regular |

## 4. 配图

- L1：封面插画 `cover_illustration.png`（已生成，全幅暖色）
- 其余页面以卡片 + 图标 + 数据锚点为主视觉，不额外生图（信息密度高，避免堆图）。

## 5. 页面映射表

| # | 文件 | 类型 | 角色 | 版式 | 主视觉 | 色彩分配 |
|---|---|---|---|---|---|---|
| 01 | 01_cover.slide | cover | hero | 全屏视觉+骑线文字 | L1 cover | 主色50%+辅色30% |
| 02 | 02_problem.slide | content | supporting | 非对称双栏+底部金句 | 双栏卡片 | 主色40%+辅色30% |
| 03 | 03_features.slide | content | supporting | 三列卡片 | 三模块卡 | 主色35%+辅色45% |
| 04 | 04_ai.slide | content | supporting | 左标题+右内容 | 三角色卡 | 主色40%+辅色30% |
| 05 | 05_token.slide | content | supporting | 上策略卡+下数据 | 数据锚点 | 主色45%+辅色25% |
| 06 | 06_ending.slide | ending | hero | 居中金句 | 大金句 | 强调色20% |
